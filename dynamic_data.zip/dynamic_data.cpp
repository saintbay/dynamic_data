﻿//#include <iostream>
//#include <queue>
//#include <random>
//#include <vector>
//#include <cmath>
//
//struct Passenger {
//    double arrivalTime;
//};
//
//struct Minibus {
//    double arrivalTime;
//    int freeSeats;
//};
//
//void simulateBusStop(double passengerInterval, double busInterval, bool isTerminal, int maxPeople, double simulationTime) {
//    std::queue<Passenger> passengers;
//    std::queue<Minibus> minibuses;
//    std::default_random_engine generator;
//    std::poisson_distribution<int> seatDistribution(12);
//
//    double currentTime = 0.0;
//    double totalWaitTime = 0.0;
//    int totalPassengers = 0;
//
//    while (currentTime < simulationTime) {
//        double nextPassengerTime = currentTime + passengerInterval;
//        passengers.push({ nextPassengerTime });
//
//        double nextBusTime = currentTime + busInterval;
//        int freeSeats = std::max(1, seatDistribution(generator)); 
//        minibuses.push({ nextBusTime, freeSeats });
//
//        while (!minibuses.empty() && minibuses.front().arrivalTime <= currentTime) {
//            Minibus bus = minibuses.front();
//            minibuses.pop();
//            int boarded = 0;
//            while (!passengers.empty() && bus.freeSeats > 0) {
//                Passenger p = passengers.front();
//                passengers.pop();
//                totalWaitTime += (currentTime - p.arrivalTime);
//                bus.freeSeats--;
//                boarded++;
//            }
//
//            totalPassengers += boarded;
//        }
//        if (passengers.size() > maxPeople) {
//            std::cout << "На остановке скопилось больше " << maxPeople
//                << " человек к моменту " << currentTime << " секунд." << std::endl;
//            break;
//        }
//
//        currentTime = std::min(nextPassengerTime, nextBusTime);
//    }
//
//    if (!passengers.empty() && passengers.size() <= maxPeople) {
//        std::cout << "Имитация завершена. Среднее время ожидания пассажира: "
//            << totalWaitTime / totalPassengers << " секунд." << std::endl;
//    }
//}
//
//int main() {
//    setlocale(LC_ALL, "Russian");
//    double passengerInterval = 10.0;
//    double busInterval = 50.0;
//    bool isTerminal = false;
//    int maxPeople = 20;
//    double simulationTime = 3600.0;  
//
//    simulateBusStop(passengerInterval, busInterval, isTerminal, maxPeople, simulationTime);
//
//    return 0;
//}










#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <ctime>

struct PrintJob {
    std::string user;
    int priority;
    double timestamp;
};
struct ComparePriority {
    bool operator()(const PrintJob& a, const PrintJob& b) {
        return a.priority < b.priority;
    }
};

void simulatePrinter() {
    std::priority_queue<PrintJob, std::vector<PrintJob>, ComparePriority> printQueue;
    std::queue<std::string> printLog;
    int jobCounter = 0;

    while (true) {
        std::cout << "\nМеню:\n1. Добавить задачу\n2. Печатать задачу\n3. Показать статистику\n4. Выход\nВаш выбор: ";
        int choice;
        std::cin >> choice;

        if (choice == 1) {
            PrintJob job;
            std::cout << "Введите имя пользователя: ";
            std::cin >> job.user;
            std::cout << "Введите приоритет задачи (целое число): ";
            std::cin >> job.priority;

            job.timestamp = std::time(nullptr);
            printQueue.push(job);
            std::cout << "Задача добавлена в очередь." << std::endl;

        }
        else if (choice == 2) {
            if (!printQueue.empty()) {
                PrintJob job = printQueue.top();
                printQueue.pop();

                std::string logEntry = "Пользователь: " + job.user +
                    ", Время: " + std::to_string((int)job.timestamp) +
                    ", Приоритет: " + std::to_string(job.priority);
                printLog.push(logEntry);

                std::cout << "Печать завершена для задачи пользователя " << job.user << std::endl;
            }
            else {
                std::cout << "Очередь печати пуста." << std::endl;
            }

        }
        else if (choice == 3) {
            if (printLog.empty()) {
                std::cout << "Статистика пуста." << std::endl;
            }
            else {
                std::cout << "Статистика печати:\n";
                while (!printLog.empty()) {
                    std::cout << printLog.front() << std::endl;
                    printLog.pop();
                }
            }

        }
        else if (choice == 4) {
            std::cout << "Выход из программы." << std::endl;
            break;

        }
        else {
            std::cout << "Неверный выбор. Попробуйте снова." << std::endl;
        }
    }
}

int main() {
    setlocale(LC_ALL, "Russian");
    simulatePrinter();
    return 0;
}
